<?php

$system_message = 'Verifying System Requirements';
$redirect = 'system_requirements';
