<?php

$system_message = 'Hello!';
$list_items ='';
$list_items .= '<li>Before going through the upgrade process, make sure you have backed up all files & database.</li>';
$list_items .= '<li>Please feel free to reach us via hello@baevox.com if you have any questions, comments, or concerns.</li>';
$list_items .= '<li>Click "Start Upgrade" to start upgrade process.</li>';

$button = [
  'text' => 'Start Upgrade',
  'process' => 'initial'
];
